-- PYQ Intelligence production schema (PostgreSQL / Supabase)
create extension if not exists pgcrypto;

create table if not exists exams (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists papers (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references exams(id) on delete cascade,
  year int not null,
  paper_label text,
  shift text,
  source_file text not null,
  source_page_start int,
  source_page_end int,
  source_fingerprint text,
  rights_status text not null default 'INTERNAL_REVIEW_REQUIRED',
  created_at timestamptz not null default now(),
  unique(exam_id, year, paper_label, shift, source_file)
);

create table if not exists questions (
  id uuid primary key default gen_random_uuid(),
  paper_id uuid references papers(id) on delete set null,
  question_number text,
  subject text,
  chapter text,
  topic text,
  subtopic text,
  question_type text,
  difficulty text,
  stem text not null,
  explanation text,
  correct_option_index int,
  provenance text not null default 'SOURCE_EXTRACTED_REVIEW_REQUIRED',
  verification_status text not null default 'NEEDS_VERIFICATION',
  source_page int,
  source_locator text,
  extraction_method text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists question_options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references questions(id) on delete cascade,
  option_index int not null,
  option_text text,
  unique(question_id, option_index)
);

create table if not exists question_assets (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references questions(id) on delete cascade,
  asset_type text not null,
  storage_path text not null,
  alt_text text,
  rights_status text not null default 'INTERNAL_REVIEW_REQUIRED'
);

create table if not exists topics (
  id uuid primary key default gen_random_uuid(),
  exam_code text not null,
  subject text not null,
  chapter text not null,
  topic text,
  unique(exam_code, subject, chapter, topic)
);

create table if not exists question_topics (
  question_id uuid not null references questions(id) on delete cascade,
  topic_id uuid not null references topics(id) on delete cascade,
  primary key(question_id, topic_id)
);

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id uuid not null references questions(id) on delete cascade,
  selected_option_index int,
  is_correct boolean,
  time_spent_seconds int,
  mode text,
  created_at timestamptz not null default now()
);

create table if not exists bookmarks (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id uuid not null references questions(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, question_id)
);

create table if not exists mistake_book (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id uuid not null references questions(id) on delete cascade,
  mistake_type text,
  note text,
  next_review_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key(user_id, question_id)
);

create table if not exists review_queue (
  id uuid primary key default gen_random_uuid(),
  question_id uuid references questions(id) on delete cascade,
  source_file text not null,
  source_page int not null,
  issue text not null,
  payload jsonb,
  status text not null default 'OPEN',
  reviewer text,
  reviewed_at timestamptz
);

create table if not exists topic_statistics (
  exam_code text not null,
  subject text not null,
  chapter text not null,
  topic text,
  total_questions int not null default 0,
  recent_questions int not null default 0,
  last_seen_year int,
  historical_priority_score numeric,
  primary key(exam_code, subject, chapter, topic)
);

insert into exams(code,name) values
('NEET','NEET (UG)'),
('JEE_MAIN','JEE Main'),
('JEE_ADVANCED','JEE Advanced')
on conflict(code) do nothing;

-- Important: historical_priority_score is a ranking heuristic, NOT a claim that a question will appear in 2027.
