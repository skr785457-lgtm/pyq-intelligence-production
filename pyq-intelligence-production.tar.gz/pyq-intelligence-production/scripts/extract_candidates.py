import fitz, pytesseract, re, json, os, hashlib
from pathlib import Path
from PIL import Image

SOURCES=[
 ('NEET','/mnt/data/NEET 30 YEAR PYQ(1).pdf'),
 ('JEE_ADVANCED','/mnt/data/JEE ADVANCE 30 YEAR PYQ(1).pdf'),
 ('JEE_MAIN','/mnt/data/JEE Main 30 YEAR PYQ 1(1).pdf'),
 ('JEE_MAIN','/mnt/data/JEE Main 30 YEAR PYQ 2(1).pdf'),
]
OUT=Path('/mnt/data/pyq-intelligence-production/data/question_candidates.jsonl')
PAGE_OUT=Path('/mnt/data/pyq-intelligence-production/data/page_text.jsonl')

def clean(s):
    s=s.replace('\u00a0',' ')
    s=re.sub(r'[ \t]+',' ',s)
    s=re.sub(r'\n{3,}','\n\n',s)
    return s.strip()

def year_context(text):
    pats=[r'(?i)(?:AIPMT|NEET)[^\n]{0,30}\b(19\d{2}|20\d{2})\b',r'(?i)JEE[- ]?(?:Advanced|Main)?[^\n]{0,30}\b(19\d{2}|20\d{2})\b',r'\b(19\d{2}|20\d{2})\b']
    found=[]
    for p in pats:
        found += [int(x) for x in re.findall(p,text)]
        if found: break
    return found[-1] if found else None

def ocr_page(page):
    pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5), alpha=False)
    img=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    return pytesseract.image_to_string(img, config='--psm 6')

def markers(exam,text):
    if exam=='NEET':
        return list(re.finditer(r'(?m)^\s*Q\.?\s*(\d{1,3})\s*$',text))
    if exam=='JEE_ADVANCED':
        return list(re.finditer(r'(?m)^\s*(\d{1,3})[.)]\s+',text))
    return list(re.finditer(r'(?m)^\s*Q\.?\s*(\d{1,3})[.)]?\s+',text))

OUT.parent.mkdir(parents=True,exist_ok=True)
# overwrite outputs
for f in [OUT,PAGE_OUT]:
    if f.exists(): f.unlink()

qid=0; page_count=0; candidate_count=0; ocr_pages=0
with OUT.open('w',encoding='utf-8') as qo, PAGE_OUT.open('w',encoding='utf-8') as po:
  for exam,path in SOURCES:
    doc=fitz.open(path)
    prev_year=None
    for pno,page in enumerate(doc,1):
      text=page.get_text('text') or ''
      used_ocr=False
      if len(text.strip())<120 and exam=='JEE_ADVANCED':
        text=ocr_page(page); used_ocr=True; ocr_pages+=1
      text=clean(text)
      y=year_context(text)
      if y: prev_year=y
      po.write(json.dumps({'exam':exam,'source_file':os.path.basename(path),'source_page':pno,'year_context':y or prev_year,'used_ocr':used_ocr,'text':text},ensure_ascii=False)+'\n')
      ms=markers(exam,text)
      # only accept plausible question numbers, with a guard against OCR noise
      for idx,m in enumerate(ms):
        qnum=int(m.group(1))
        if qnum>300: continue
        end=ms[idx+1].start() if idx+1<len(ms) else len(text)
        block=clean(text[m.start():end])
        if len(block)<25: continue
        # discard obvious answer-only blocks
        if block.lower().startswith('answer answer'): continue
        qid+=1
        ans=None
        am=re.search(r'(?is)\bAns\.?\s*\[\s*([1-4])\s*\]',block)
        if am: ans=int(am.group(1))-1
        rec={'id':f'candidate_{qid:07d}','exam':exam,'year':y or prev_year,'source_file':os.path.basename(path),'source_page':pno,'question_number':qnum,'question_raw':block,'answer_index_if_printed':ans,'provenance':'SOURCE_EXTRACTED_REVIEW_REQUIRED','verification_status':'NEEDS_VERIFICATION','used_ocr':used_ocr}
        qo.write(json.dumps(rec,ensure_ascii=False)+'\n'); candidate_count+=1
      page_count+=1
print(json.dumps({'pages_processed':page_count,'ocr_pages':ocr_pages,'question_candidates':candidate_count},indent=2))
