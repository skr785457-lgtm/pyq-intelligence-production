import fitz, json, re, hashlib, os
from pathlib import Path

FILES = [
    ('NEET', '/mnt/data/NEET 30 YEAR PYQ(1).pdf'),
    ('JEE_ADVANCED', '/mnt/data/JEE ADVANCE 30 YEAR PYQ(1).pdf'),
    ('JEE_MAIN_1', '/mnt/data/JEE Main 30 YEAR PYQ 1(1).pdf'),
    ('JEE_MAIN_2', '/mnt/data/JEE Main 30 YEAR PYQ 2(1).pdf'),
]
OUT = Path('/mnt/data/pyq-intelligence-production/data/source_manifest.json')

def years(text):
    ys=[]
    for y in re.findall(r'(?<!\d)(19(?:9\d)|20(?:0\d|1\d|2[0-6]))(?!\d)', text):
        ys.append(int(y))
    return sorted(set(ys))

def question_markers(text):
    return len(re.findall(r'(?m)^\s*(?:Q\.?\s*)?\d{1,3}[.)]?\s+', text))

manifest={'generated_at':'2026-09-14','files':[],'totals':{}}
for exam,path in FILES:
    p=Path(path); doc=fitz.open(path)
    pages=[]; total_chars=0; low_text=0; total_qmarkers=0; all_years=set()
    for i,page in enumerate(doc,1):
        text=page.get_text('text') or ''
        n=len(text.strip()); total_chars+=n
        if n < 120: low_text+=1
        qs=question_markers(text); total_qmarkers+=qs
        ys=years(text); all_years.update(ys)
        pages.append({'page':i,'chars':n,'question_markers':qs,'years':ys,'needs_visual_review':n<120})
    raw=open(path,'rb').read(1024*1024)
    sha=hashlib.sha256(raw).hexdigest()[:16]
    manifest['files'].append({'exam':exam,'filename':p.name,'path':str(p),'bytes':p.stat().st_size,'pages':len(doc),'sha256_prefix':sha,'total_text_chars':total_chars,'low_text_pages':low_text,'question_markers':total_qmarkers,'detected_years':sorted(all_years),'page_inventory':pages})

manifest['totals']={'files':len(manifest['files']),'pages':sum(x['pages'] for x in manifest['files']),'low_text_pages':sum(x['low_text_pages'] for x in manifest['files']),'question_markers':sum(x['question_markers'] for x in manifest['files'])}
OUT.write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(manifest['totals'],indent=2))
for x in manifest['files']:
 print(x['exam'],x['pages'],'pages,',x['low_text_pages'],'low-text,',x['question_markers'],'question markers, years',x['detected_years'][:5],'...',x['detected_years'][-5:])
