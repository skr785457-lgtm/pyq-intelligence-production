# Ingestion scripts

`inventory_pdfs.py` inventories pages, text density and source metadata.

`extract_candidates.py` extracts text and creates review-required question candidates. For image-heavy JEE Advanced pages it uses Tesseract OCR. The current run was intentionally bounded by execution time, so `question_candidates.jsonl` is a partial first-pass dataset and **must not be treated as complete**.
