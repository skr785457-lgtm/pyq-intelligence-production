# PYQ Intelligence — Production Foundation

Working name for a multi-exam PYQ practice platform covering **NEET, JEE Main and JEE Advanced**.

## What is included

- Your existing HTML app preserved as `legacy-ui/index.html`.
- A PostgreSQL/Supabase production schema in `schema.sql`.
- PDF source inventory in `data/source_manifest.json`.
- A resumable extraction pipeline in `scripts/`.
- Extracted page text / question candidates generated during the first ingestion pass.

## Source inventory

The four uploaded PDFs contain **3,022 pages total**:

| Source | Pages |
|---|---:|
| NEET 30 Year PYQ | 805 |
| JEE Advanced 30 Year PYQ | 1,080 |
| JEE Main 30 Year PYQ 1 | 610 |
| JEE Main 30 Year PYQ 2 | 527 |

Do not treat the number of regex question markers as the question count: options, answer blocks and OCR artifacts can look like question markers. The production question count must be computed after structured parsing and review.

## Verification model

Every imported record starts as:

`SOURCE_EXTRACTED_REVIEW_REQUIRED` → `NEEDS_VERIFICATION`

Only after checking the source page should it become `VERIFIED_PYQ` / `ANSWER_VERIFIED`.

Keep these separate from predictive labels such as `CONCEPT_REPEAT` or `PROBABLE_2027`.

The app's old "Probability Engine" should be presented as a **Historical Priority Score**. Historical frequency can rank topics, but it cannot establish that a question will appear in NEET/JEE 2027.

## Recommended production stack

- Frontend: Next.js + Tailwind
- Database/Auth: Supabase PostgreSQL + Supabase Auth
- Storage: Supabase Storage for permitted assets only
- Hosting: Vercel or equivalent
- Admin: private review queue for source-page verification

## Ingestion rules

1. Preserve `source_file` and `source_page` for every question.
2. Preserve paper/year/shift when the source supports it.
3. Do not invent chapter/topic mappings when the source does not support them; map them in a separate review/enrichment step.
4. Diagrams and equations that OCR cannot reliably capture go to the review queue.
5. Never mark an answer as verified solely because an OCR engine guessed it.
6. Keep the raw source PDFs private unless redistribution rights have been established.

## Publishing / rights gate

The official JEE Advanced site publishes past papers, and NTA publishes administered question papers and answer-key material. Public availability does **not by itself establish that a third party may republish the complete PDFs or a commercial question bank**. Before launch, confirm the rights/licensing position for the exact source material. A safer architecture is to keep source PDFs internal, publish only content you are authorized to distribute, and/or link users to official sources where appropriate.

## Next build steps

1. Finish OCR/extraction for image-heavy JEE Advanced pages.
2. Parse questions/options into normalized records.
3. Add source-page visual review for equations/figures/OCR uncertainty.
4. Verify answer keys against authoritative sources where available.
5. Enrich subject/chapter/topic tags.
6. Import verified records into Supabase.
7. Replace browser/local-state storage with authenticated database persistence.
8. Add practice, full mock tests, bookmarks, mistake book, spaced revision and analytics.
9. Add historical trend ranking without presenting it as a guaranteed 2027 prediction.
10. Run a rights/licensing check before public launch.
